import React from "react";
import "./App.css";
import {useSelector,useDispatch} from "react-redux";
import {incNumber,decNumber} from "./actions/index"
const App = () => {
  const myState = useSelector((state)=>state.changeTheNumber);
  const dispatch = useDispatch();

  // const handleInputChange = (e) => {
  //   dispatch(incNumber(e.target.value)); 
  // };

  return (
    <>
      <div className="container">
        <h1>Increment / Decrement counter</h1>
        <h4>using react and redux</h4>
      </div>
      <div className="quantity">
        <a className="quantity_minus" title="Decrement" onClick={()=>dispatch(decNumber(5))}> <span className="btnColor" > MINUS </span></a>
        <h1> {myState} </h1>
        {/* <input name="quantity" type ="text" className="quantity_input"    onChange={handleInputChange} placeholder="Enter the number"/> */}
        <a className ="quantity_plus" title="Increment" onClick = {() => dispatch(incNumber(5))}><span className="btnColor"> ADD </span></a>
      </div>
    </>
  );
};

export default App;
