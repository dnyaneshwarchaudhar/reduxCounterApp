export const incNumber=((num)=>{
     return{
        type:"INCREMENT",
        payload : num
     }
});

export const decNumber = ((check)=>{
    return{
        type:"DECREMENT",
        payload : check
    }
})